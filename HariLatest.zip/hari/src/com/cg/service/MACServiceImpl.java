package com.cg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.MACDAO;
import com.cg.dao.MACDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public class MACServiceImpl implements MACService{

	MACDAO dao=null;
	public MACServiceImpl() {
		super();
		dao=new MACDAOImpl();
	}

	@Override
	public List<ProgramScheduled> getAllScheduledPrograms() {
		return dao.getAllScheduledPrograms();
	}

	@Override
	public String updateStatus(String status, int id) {
		return dao.updateStatus(status, id);
	}

	@Override
	public int setInterviewDate(LocalDate date, int id) {
		return dao.setInterviewDate(date, id);
	}

	@Override
	public List<Application> showApplicationByStatus(String status) {
		return dao.showApplicationByStatus(status);
	}

	@Override
	public List<Application> getAllApplications() {
		// TODO Auto-generated method stub
		return dao.getAllApplications();
	}

	@Override
	public String ReturnStatus(int id) {
		// TODO Auto-generated method stub
		return dao.ReturnStatus(id);
	}

	@Override
	public boolean isValidDoi(String doi) 
	{
		String regex = "^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}$"; 
		Pattern pattern = Pattern.compile(regex); 
	Matcher matcher = pattern.matcher((CharSequence)doi); 
		return matcher.matches();
	}

//	public  boolean isValidDob(String  localDate)
//	{
//		String regex = "^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$"; 
//		Pattern pattern = Pattern.compile(regex); 
//		Matcher matcher = pattern.matcher((CharSequence)localDate); 
//		return matcher.matches(); 
//	}
	
}
