package com.cg.client;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.Exception.UASException;
import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;
import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;
import com.cg.util.MyStringDateUtil;

public class MemberLoginMain {

	MACService mac = null;
	UserDao chk = null;
	AdminService admin = null;

	public void Login() throws UASException {
		chk = new UserDaoImpl();
		int LoginAttempt = 0;
		int choice = -1;
		mac = new MACServiceImpl();
		Scanner sc = new Scanner(System.in);
		while (true) {
			if (LoginAttempt > 2) {
				System.out.println("Too many Attempts! \n Exiting Application...");
				sc.close();
				System.exit(0);
			} else {
				System.out.println("You have " + (3 - LoginAttempt) + " attempts remaining");
				System.out.println("Login Id: ");
				String login = sc.next();
				System.out.println("Password:");
				String pass = sc.next();
				String message = chk.ReturnRole(login, pass);
				if (message.equals("MAC")) {
					System.out.println("\n ******************"
							+ "You are now Logged in as a Member of Admission Committe(MAC)***************************");
					MACShow();
					return;
				} else if (message.equals("Admin")) {
					System.out.println("\n**********************************"
							+ "You are now Logged in as an admin*****************************");
					try {
						adminShow();
					} catch (Exception e) {
						throw new UASException(e.getMessage());
					}
					return;
				} else
					System.out.println(message);
				LoginAttempt++;
			}
		}
	}

	private void adminShow() throws UASException {

		while (true) {
			try {
				admin = new AdminServiceImpl();
				int choice = -1;
				Scanner sc = new Scanner(System.in);
				System.out.println("\n\n**************************************************");
				System.out.println("\nSelect an Option:");
				System.out.println("\t1. Add a Program\n\t" + "2. Delete a Program\n\t" + "3. Schedule a Program\n\t"
						+ "4. View Scheduled Programs\n\t" + "5. Sort Applications based on status\n\t"
						+ "6. View All Programs Offered");
				System.out.println("\n**************************************************");
				System.out.println("Enter 0 to Return");
				System.out.println("Enter your choice:");
				choice = Integer.parseInt(sc.nextLine());
				switch (choice) {
				case 1:

					System.out.println("\n\nEnter details to make a new Program");
					ProgramOffered program = new ProgramOffered();
					System.out.println("\t\t1. Enter Program Name (max 5 characters):");
					program.setProgramName(sc.nextLine().toUpperCase());
					System.out.println("\t\t1. Enter some description about the program: ");
					program.setDescription(sc.nextLine());
					System.out.println("\t\t1. Enter Applicant Eligibility criteria: ");
					program.setApplicantEligibility(sc.nextLine());
					System.out.println("\t\t1. Enter Duration of the Program (No of Days): ");
					program.setDuration(Integer.parseInt(sc.nextLine()));
					System.out.println("\t\t1. Enter the degree offered with this program: ");
					program.setDegreeCertificateOffered(sc.nextLine());

					try {
						admin.addProgram(program);
						System.out.println("Program Added Successfully! ");
					} catch (Exception e) {
						throw new UASException("Invalid Input");
					}

					break;

				case 2:
					System.out.println("\n\nEnter Program Name to be Deleted: ");
					String progName = sc.nextLine();
					admin.deleteProgram(progName);
					System.out.println("Program Deleted Successfully!");
					break;

				case 3:
					// Doubt 2
					ProgramScheduled obj = new ProgramScheduled();
					System.out.println("\nPrograms Offered: ");
					ArrayList<String> list3 = admin.getProgramsOffered();
					Iterator<String> iterator3 = list3.iterator();
					while (iterator3.hasNext())
						System.out.println("\t" + iterator3.next());
					System.out.println("\n\nEnter a Program from Above: ");
					obj.setProgramName(sc.nextLine().toUpperCase());
					System.out.println("\nEnter a ProgramId (max 5 characters): ");
					obj.setScheduledProgramId(sc.nextLine());
					System.out.println("\nEnter a Location: ");
					obj.setLocation(sc.nextLine());
					System.out.println("\nEnter a Start Date in dd-MM-yyyy format: ");
					obj.setStartDate(MyStringDateUtil.fromStringToSqlDate(sc.nextLine()));
					System.out.println("\nEnter a End Date in dd-MM-yyyy format: ");
					obj.setEndDate(MyStringDateUtil.fromStringToSqlDate(sc.nextLine()));
					System.out.println("\nEnter No of sessions per week: ");
					obj.setSessionsPerWeek(Integer.parseInt(sc.nextLine()));
					try {
						admin.scheduleProgram(obj);
						System.out.println("Program Scheduled!");
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;

				case 4:
					System.out.println("\n\nEnter Start Date in dd-MM-yyyy format: ");
					String startDate = sc.nextLine();
					System.out.println("\n\nEnter End Date in dd-MM-yyyy format: ");
					String endDate = sc.nextLine();
					ArrayList<ProgramScheduled> list = admin.getScheduledProgram(
							MyStringDateUtil.fromStringToSqlDate(startDate),
							MyStringDateUtil.fromStringToSqlDate(endDate));
					System.out.println("\nFollowing are the Programs: \n");
					Iterator<ProgramScheduled> iterator = list.iterator();
					ProgramScheduled ps;
					System.out.format("\t%-30s %-20s %-20s %-20s %-20s %-20s", "SCHEDULED PROGRAM ID", "PROGRAM NAME",
							"LOCATION", "START DATE", "END DATE", "SESSIONS/WEEK");
					while (iterator.hasNext()) {
						ps = iterator.next();
						System.out.println("");
						System.out.format("\t%-30s %-20s %-20s %-20s %-20s %-20s", ps.getScheduledProgramId(),
								ps.getProgramName(), ps.getLocation(), ps.getStartDate(), ps.getEndDate(),
								ps.getSessionsPerWeek());
					}
					break;

				case 5:
					System.out.println("\n\n Choose one from the Following: ");
					System.out.println("\n\t\t\t (a) Applied" + "\n\t\t\t (b) Accepted" + "\n\t\t\t (c) Rejected");

					String status = null;
					char ch = sc.nextLine().charAt(0);
					if (ch == 'a')
						status = "APPLIED";
					else if (ch == 'b')
						status = "ACCEPTED";
					else if (ch == 'c')
						status = "REJECTED";
					else {
						System.out.println("Wrong Option");
						return;
					}
					ArrayList<Application> list2 = admin.getStatus(status);
					System.out.println("\nApplicants with status as: " + status);
					Iterator<Application> iterator2 = list2.iterator();
					Application app = new Application();
					System.out.format("\t%-20s %-20s %-20s %-30s %-20s %-25s %-25s %-30s %-11s ", "APPLICATION ID",
							"FULL NAME", "DOB", "HIGHEST QUALIFICATION", "MARKS OBTAINED", "GOALS", "EMAIL ID",
							"SCHEDULED PROGRAM ID", "DATE OF INTERVIEW");
					while (iterator2.hasNext()) {
						app = iterator2.next();
						System.out.println("");
						System.out.format("\t%-20d %-20s %-20s %-30s %-20d %-25s %-25s %-30s %-11s",
								app.getApplicationId(), app.getFullName(), app.getDateOfBirth().toString(),
								app.getHighestQualification(), app.getMarksObtained(), app.getGoals(), app.getEmailId(),
								app.getScheduledProgramId(), app.getDateOfInterview());
					}
					break;

				case 6:
					admin = new AdminServiceImpl();
					ArrayList<ProgramOffered> lists = admin.getProgramsOfferedDetails();
					System.out.println("\nFollowing are the Programs: \n");
					Iterator<ProgramOffered> itr = lists.iterator();
					ProgramOffered po;
					System.out.format("\t%-20s %-30s %-30s %-20s %-20s", "PROGRAM NAME", "DESCRIPTION", "ELIGIBILITY",
							"DURATION", "CERTIFICATE OFFERED");
					while (itr.hasNext()) {
						po = itr.next();
						System.out.println("");
						System.out.format("\t%-20s %-30s %-30s %-20s %-20s", po.getProgramName(), po.getDescription(),
								po.getApplicantEligibility(), po.getDuration(), po.getDegreeCertificateOffered());
					}
					break;

				case 0:
					return;

				default:
					System.out.println("Sorry ! invalid keystroke... try again");
				}
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	private void MACShow() {
		while (true) {
			int choice = -1;
			Scanner sc = new Scanner(System.in);
			System.out.println("\n\n**************************************************");
			System.out.println("\nSelect an Option:");
			System.out.println("\t1. Get all Scheduled Programs\n\t" + "2. Show Application by Status\n\t"
					+ "3. Get All Applicantions");
			System.out.println("\n**************************************************");
			System.out.println("Enter 0 to Return");
			System.out.println("Enter your choice:");
			choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 0:
				return;

			case 1:
				List<ProgramScheduled> list = mac.getAllScheduledPrograms();
				System.out.println("/n Following are the Programs: ");
				Iterator<ProgramScheduled> iterator = list.iterator();
				ProgramScheduled ps;
				System.out.format("\t%-30s %-20s %-20s %-20s %-20s %-20s", "SCHEDULED PROGRAM ID", "PROGRAM NAME",
						"LOCATION", "START DATE", "END DATE", "SESSIONS/WEEK");
				while (iterator.hasNext()) {
					ps = iterator.next();
					System.out.println("");
					System.out.format("\t%-30s %-20s %-20s %-20s %-20s %-20s", ps.getScheduledProgramId(),
							ps.getProgramName(), ps.getLocation(), ps.getLocation(), ps.getStartDate(), ps.getEndDate(),
							ps.getEndDate(), ps.getSessionsPerWeek());
				}
				break;

			case 2:
				System.out.println("\n\n Choose one from the Following: ");
				System.out.println("\n\t\t\t (a) Applied" + "\n\t\t\t (b) Accepted" + "\n\t\t\t (c) Rejected");
				String status2 = null;
				char ch2 = sc.nextLine().charAt(0);
				if (ch2 == 'a')
					status2 = "APPLIED";
				else if (ch2 == 'b')
					status2 = "ACCEPTED";
				else if (ch2 == 'c')
					status2 = "REJECTED";
				else {
					System.out.println("Wrong Option");
					return;
				}
				List<Application> list2 = mac.showApplicationByStatus(status2);
				Application app = new Application();
				Iterator<Application> iterator2 = list2.iterator();
				if (!iterator2.hasNext()) {
					System.out.println("There are no applicants who's status is " + status2);
				} else {
					System.out.println("\n Following are the Applicants: ");
					System.out.format("%-20s %-20s %-20s %-30s %-20s %-25s %-25s %-30s %-11s", "APPLICATION ID",
							"FULL NAME", "DOB", "HIGHEST QUALIFICATION", "MARKS OBTAINED", "GOALS", "EMAIL ID",
							"SCHEDULED PROGRAM ID", "DATE OF INTERVIEW");
					while (iterator2.hasNext()) {
						app = iterator2.next();
						System.out.println("");
						System.out.format("%-20d %-20s %-20s %-30s %-20d %-25s %-25s %-30s %-11s",
								app.getApplicationId(), app.getFullName(), app.getDateOfBirth().toString(),
								app.getHighestQualification(), app.getMarksObtained(), app.getGoals(), app.getEmailId(),
								app.getScheduledProgramId(), app.getDateOfInterview());

					}
				}
				break;

			case 3:
				System.out.println("\nThese are the available Applications: ");
				List<Application> list3 = mac.getAllApplications();
				Iterator<Application> iterator3 = list3.iterator();
				app = new Application();
				System.out.format("%-20s %-20s %-20s %-30s %-20s %-25s %-25s %-30s %-15s %-11s", "APPLICATION ID",
						"FULL NAME", "DOB", "HIGHEST QUALIFICATION", "MARKS OBTAINED", "GOALS", "EMAIL ID",
						"SCHEDULED PROGRAM ID", "STATUS", "DATE OF INTERVIEW");
				while (iterator3.hasNext()) {
					app = iterator3.next();
					System.out.println("");
					System.out.format("%-20d %-20s %-20s %-30s %-20d %-25s %-25s %-30s %-15s %-11s",
							app.getApplicationId(), app.getFullName(), app.getDateOfBirth().toString(),
							app.getHighestQualification(), app.getMarksObtained(), app.getGoals(), app.getEmailId(),
							app.getScheduledProgramId(), app.getStatus(), app.getDateOfInterview());

				}
				System.out.println("\nSelect an Option:");
				System.out.println("\t1. Update Status\n" + "\t2. Set Interview Date");
				int ch = Integer.parseInt(sc.nextLine());
				if (ch == 1) {
					System.out.println("\nEnter Applicant Id: ");
					int Id = Integer.parseInt(sc.nextLine());
					System.out.println("\nEnter status: ");
					String status = sc.nextLine();
					String status4 = mac.ReturnStatus(Id);
					if (status4.equals("ACCEPTED") || status4.equals("REJECTED")) {
						System.out.println(
								"\nSorry cannot perform this operation as this Applicant is already " + status4);
						break;
					} else {
						mac.updateStatus(status, Id);
						System.out.println("\nStatus Updated! ");
						break;
					}
				} else if (ch == 2) {
					System.out.println("\nEnter Applicant Id: ");
					int Id2 = Integer.parseInt(sc.nextLine());
					while (true) {
						String date = null;
						LocalDate today = LocalDate.now();
						do {
							System.out.println("\nEnter Date of interview in dd-mm-yyyy format: ");
							date = sc.next();
							if (!mac.isValidDoi(date))
								System.out.println("Enter a Valid Date!");
						} while (!mac.isValidDoi(date));
						LocalDate date1 = MyStringDateUtil.fromStringToLocalDate(date);
						String status3 = mac.ReturnStatus(Id2);
						if (status3.equals("ACCEPTED") || status3.equals("REJECTED")) {
							System.out.println(
									"\nSorry cannot set interview Date as this Applicant is already " + status3);
							break;
						} else {
							if (today.compareTo(date1) < 0) {
								mac.setInterviewDate(date1, Id2);
								System.out.println("\nInterview Date Updated! ");
								break;
							} else {
								System.out.println("Interview Date should be after today's date");
							}

						}
					}
				} else {
					System.out.println("Wrong Keystroke!");

				}
				break;
			default:
				System.out.println("Sorry ! invalid keystroke... try again");
			}
		}

	}
}